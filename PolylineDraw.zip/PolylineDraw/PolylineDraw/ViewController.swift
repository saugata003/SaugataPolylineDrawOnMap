//
//  ViewController.swift
//  PolylineDraw
//
//  Created by Apple on 12/12/19.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
class CustomPin: NSObject, MKAnnotation {
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    init(pinTitle: String, pinSubTitle: String, pinCoordinate: CLLocationCoordinate2D) {
        self.title = pinTitle
        self.subtitle = pinSubTitle
        self.coordinate = pinCoordinate
    }
}
class ViewController: UIViewController, CLLocationManagerDelegate {
    @IBOutlet weak var mapView: MKMapView!
    var manager = CLLocationManager()
    var userLocation = CLLocationCoordinate2D()
    override func viewDidLoad() {
        super.viewDidLoad()
        UIApplication.shared.isStatusBarHidden = true
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.requestAlwaysAuthorization()
        manager.startUpdatingLocation()
        mapView.showsUserLocation = true
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    func configureMap() {
        let sourceLocation = CLLocationCoordinate2D(latitude: userLocation.latitude, longitude: userLocation.longitude)
        let destinationLocation = CLLocationCoordinate2D(latitude: 22.572620, longitude: 88.430944)
        
        let sourcePin = CustomPin(pinTitle: "Azure Computer", pinSubTitle: "", pinCoordinate: sourceLocation)
        let destinationPin = CustomPin(pinTitle: "Techno India College", pinSubTitle: "", pinCoordinate: destinationLocation)
        mapView.addAnnotation(sourcePin)
        mapView.addAnnotation(destinationPin)
        
        let sourcePlaceMark = MKPlacemark(coordinate: sourceLocation)
        let destinationPlaceMark = MKPlacemark(coordinate: destinationLocation)
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = MKMapItem(placemark: sourcePlaceMark)
        directionRequest.destination = MKMapItem(placemark: destinationPlaceMark)
        directionRequest.transportType = .automobile
        
        let direction = MKDirections(request: directionRequest)
        direction.calculate { (response, error) in
            guard let directionResponse = response else {
                if let _ = error {
                    print("we have getting error in locations==\(error.debugDescription)")
                }
                return
            }
            let route = directionResponse.routes[0]
            self.mapView.addOverlay(route.polyline, level: .aboveRoads)
            let rect = route.polyline.boundingMapRect
            self.mapView.setRegion(MKCoordinateRegion(rect), animated: true)
        }
        
        
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        userLocation.latitude = locations[0].coordinate.latitude
        userLocation.longitude = locations[0].coordinate.longitude
        configureMap()
    }
}

extension ViewController: MKMapViewDelegate {
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        for item in mapView.subviews where item.isKind(of: MKPolylineRenderer.self)  {
            item.removeFromSuperview()
        }
        let renderer = MKPolylineRenderer(overlay: overlay)
        renderer.strokeColor = .blue
        renderer.lineWidth = 4
        return renderer
    }
}
